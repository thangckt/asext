"""ASEXT: Python package extends functions of ASE (Atomic Simulation Environment).

<img src="./_assets/image/logo_clff.svg" style="float: left; margin-right: 20px" width="120"/>

Developed by [C.Thang Nguyen](https://thangckt.github.io)

This package was originally developed as part of the [CLFF](https://thangckt.github.io/clff/) project.
"""

from pathlib import Path

ASEXT_ROOT = Path(__file__).parent

try:
    from ._version import version as __version__
except ImportError:
    __version__ = "0.1_fallback"

__author__ = "C.Thang Nguyen"
__contact__ = "http://thangckt.github.io/email"
